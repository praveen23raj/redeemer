import { Component, ElementRef, HostListener, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { RevealDirective } from '../../shared/reveal/reveal.directive';
import { IconComponent } from '../../shared/icon/icon.component';

@Component({
  selector: 'app-leadership',
  standalone: true,
  imports: [CommonModule, RouterModule, RevealDirective, IconComponent],
  templateUrl: './leadership.component.html',
  styleUrls: ['./leadership.component.css']
})
export class LeadershipComponent {

  selectedLeader: any = null;
  @ViewChild('closeBtn') closeBtn?: ElementRef<HTMLButtonElement>;
  private lastFocus: HTMLElement | null = null;

  leaders = [
    
    {
      id: 'karunakaran',
      name: 'Rev. P. Karunakaran',
      title: 'Founder & Senior Pastor',
      image: 'assets/leaders/karunakaran.webp',
      shortDescription:
        'Founder of Redeemer Evangelical Prayer House since 2010, faithfully leading the congregation with vision and prayer.'
    },
     {
      id: 'selena',
      name: 'Selena Karunakaran',
      title: 'Pastor',
      image: 'assets/leaders/selena.webp',
      shortDescription:
        'Founder of Redeemer Evangelical Prayer House since 2010, faithfully leading the congregation with vision and prayer.'
    },
    {
      id: 'gilbert',
      name: 'Gilbert Raj K',
      title: 'Pastor',
      image: 'assets/leaders/gilbert.webp',
      shortDescription: 'Pastor incharge of Redeemer Evangelical Prayer House since 2020.'
    },
      {
      id: 'prakash',
      name: 'Prakash M',
      title: 'Evangelist',
      image: 'assets/leaders/prakash.webp',
      shortDescription: 'Evangelist of Redeemer Evangelical Prayer House.'
    },
   {
  id: 'shantha',
  name: 'Shanthi Gilbert',
  title: 'Evangelist',
  image: 'assets/leaders/shantha.webp',
  focus: '38% 20%',
  shortDescription:
    'A passionate woman of Christ, devoted to prayer, evangelism, and empowering lives through God’s Word.'
},
{
      id: 'praveen',
      name: 'Praveen Raj V',
      title: 'Believer & Developer',
      image: 'assets/leaders/praveen.webp',
      shortDescription:
        'Believer and Developer of Redeemer Evangelical Prayer House , serving through technology and faith.'
    }
  ];

  openProfile(leader: any) {
    this.lastFocus = document.activeElement as HTMLElement;
    this.selectedLeader = leader;
    document.body.style.overflow = 'hidden';
    setTimeout(() => this.closeBtn?.nativeElement.focus());
  }

  closeProfile() {
    this.selectedLeader = null;
    document.body.style.overflow = '';
    this.lastFocus?.focus();
  }

  @HostListener('document:keydown.escape')
  onEsc() {
    if (this.selectedLeader) this.closeProfile();
  }

  ngOnDestroy() {
    document.body.style.overflow = '';
  }
}
