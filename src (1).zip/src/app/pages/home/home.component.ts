import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { RevealDirective } from '../../shared/reveal/reveal.directive';
import { IconComponent } from '../../shared/icon/icon.component';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterModule, RevealDirective, IconComponent],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  announcements = [
    { title: 'Sunday Worship', when: 'Every Sunday', tag: 'Weekly', badge: '9:30 AM – 12:30 PM', icon: 'clock',
      image: 'assets/home/sunday-worship.webp' },
    { title: 'Holy Communion', when: 'Every 1st Sunday', tag: 'Monthly', badge: 'Sacred Sacrament', icon: 'cup',
      image: 'assets/home/holy-communion.webp' },
    { title: 'Church Anniversary', when: 'March 3rd Every Year', tag: 'Annual', badge: 'Celebration', icon: 'sparkle',
      image: 'assets/home/church-anniversary.webp' }
  ];
}
