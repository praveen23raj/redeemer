import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { RevealDirective } from '../../shared/reveal/reveal.directive';
import { IconComponent } from '../../shared/icon/icon.component';

interface Ministry { icon: string; title: string; description: string; time?: string; }

@Component({
  selector: 'app-ministries',
  standalone: true,
  imports: [CommonModule, RouterModule, RevealDirective, IconComponent],
  templateUrl: './ministries.component.html',
  styleUrls: ['./ministries.component.css']
})
export class MinistriesComponent {
  ministries: Ministry[] = [
    { icon: 'church', title: 'Sunday Worship',
      description: 'Join us for powerful worship, Spirit-filled praise, and life-transforming Word every Sunday.',
      time: 'Every Sunday • 9:30 AM – 12:30 PM' },
    { icon: 'flame', title: 'Youth Fellowship',
      description: 'A vibrant gathering empowering young people to grow spiritually, build leadership, and walk boldly in Christ.' },
    { icon: 'heart', title: 'Women Fellowship',
      description: 'A blessed time of prayer, encouragement, and sisterhood, strengthening women in faith and purpose.',
      time: 'Every Friday • 7:00 PM – 8:00 PM' },
    { icon: 'star', title: 'Children Ministry',
      description: 'Teaching children biblical values through engaging lessons, activities, and joyful worship.' },
    { icon: 'hands', title: 'Prayer Ministry',
      description: 'Dedicated to interceding for families, the church, and the community through united prayer.' },
    { icon: 'book', title: 'Sunday Class Ministry',
      description: 'Focused teaching sessions designed to deepen biblical understanding for believers of all ages.' },
    { icon: 'music', title: 'Worship Team',
      description: "Leading the congregation into God's presence through music, praise, and heartfelt worship." },
    { icon: 'bookOpen', title: 'Bible Study',
      description: 'Systematic and practical study of Scripture to build strong, grounded believers in Christ.' }
  ];

  get weekly() { return this.ministries.filter(m => m.time); }
}
