import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { RevealDirective } from '../../shared/reveal/reveal.directive';
import { IconComponent } from '../../shared/icon/icon.component';

@Component({
  selector: 'app-contact',
  standalone: true,
  imports: [CommonModule, RevealDirective, IconComponent],
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent {
  mapsLink = 'https://maps.app.goo.gl/j6x47LK8eJK5kTzE6';
  mapEmbed: SafeResourceUrl;

  leaders = [
    { badge: 'Pastor In-charge', name: 'K. Gilbert Raj', role: 'Senior Pastor', tel: '9845443008', phone: '+91 98454 43008', featured: true },
    { badge: 'Founder & Sr. Pastor', name: '(Late) Rev. P. Karunakaran', role: 'In Loving Memory',
      memory: 'His legacy of faith lives on in every life he touched.' },
    { badge: 'Evangelist', name: 'Evan. Prakash', role: 'Evangelist', tel: '9980338541', phone: '+91 99803 38541' },
    { badge: 'Evangelist', name: 'Evan. Krupananda', role: 'Evangelist', tel: '9739180776', phone: '+91 97391 80776' },
    { badge: 'Pastor', name: 'Pastor Seleena Karunakaran', role: 'Pastor', tel: '9945392964', phone: '+91 99453 92964' }
  ];

  // Social links — replace '#' with the real page URLs when available
  socials = [
    { label: 'Facebook', href: '#', svg: 'fb' },
    { label: 'Instagram', href: '#', svg: 'ig' },
    { label: 'YouTube', href: '#', svg: 'yt' }
  ];

  constructor(sanitizer: DomSanitizer) {
    this.mapEmbed = sanitizer.bypassSecurityTrustResourceUrl(
      'https://www.google.com/maps?q=No.61,Ex-Servicemen+Housing+Colony,Gunjurpalya,Bengaluru-560087&output=embed'
    );
  }
}
